/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cuba;

/**
 *
 * @author USER
 */
import java.util.InputMismatchException;
import java.util.Scanner;
public class Cuba {
    public static void main(String[] args) {
        
        int choice=0;
        int num1, num2, addition, substraction, division, multiplication, modulus;
        Scanner um = new Scanner (System.in);
        
        //The menu display
        System.out.println("Arithmetic operators :");
        System.out.println("1.Addition");
        System.out.println("2.Substraction");
        System.out.println("3.Division");
        System.out.println("4.Multiplication");
        System.out.println("5.Modulus");
        try{
        //User choose the operators
        System.out.println("Choose an arithmetic operators (1-5)");
        choice = um.nextInt();
        
        //User enter the first sum
        System.out.println("Please enter first sum :");
        num1 = um.nextInt();
        
        //User enter the second sum
        System.out.println("Please enter second sum :");
        num2 = um.nextInt();
         
        switch(choice){
            
            //Calculate the addition between num1 and num2
            case 1 : addition = num1 + num2;
            System.out.println("add = " + addition);break;
        
            //Calculate the substraction between num1 and num2
            case 2 : substraction = num1 - num2;
            System.out.println("subs = "+substraction);break;
            
            //Calculate the divison between num1 and num2
            case 3 : division = num1 / num2;
            System.out.println("devide = "+division);break;
        
            //Multiply between num1 and num2
            case 4 : multiplication = num1 * num2;
            System.out.println("multiply = "+multiplication);break;

            //Modulus between num1 and num2
            case 5 : modulus = num1 % num2;
            System.out.println("modul = "+modulus);break;
        }
        }
        catch(InputMismatchException ime)
        {System.out.println("Invalid Input!!!!!");}
        System.out.println("after catch");
            
                   
    }
    
}

   
